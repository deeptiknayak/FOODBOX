export class Item {
itemId: number;
itemName: string;
itemImage: string;
itemPrice: number;
itemCuisine: string;
description: string;
availability: boolean;
quantity: number;
}
